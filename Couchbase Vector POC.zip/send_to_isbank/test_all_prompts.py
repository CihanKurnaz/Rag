import os
import openai
import argparse
import csv
from couchbase.cluster import Cluster
from couchbase.options import ClusterOptions
from couchbase.auth import PasswordAuthenticator
from langchain_couchbase import CouchbaseVectorStore
from langchain_openai import OpenAIEmbeddings
from dotenv import load_dotenv
from datetime import timedelta
load_dotenv() 
# Initialize OpenAI API
openai_api_key = os.getenv("OPENAI_API_KEY")
client = openai.OpenAI()

# Initialize Couchbase connection
pa = PasswordAuthenticator(os.getenv("CB_USERNAME"), os.getenv("CB_PASSWORD"))
cluster = Cluster("couchbase://" + os.getenv("CB_HOSTNAME"), ClusterOptions(pa))


cluster.wait_until_ready(timedelta(seconds=5))

bucket = cluster.bucket("isbank")
scope = bucket.scope("data")

# Function to generate a vector using OpenAI's embeddings API
def generate_embedding(text):
    response = client.embeddings.create(input=[text], model="text-embedding-ada-002")
    return response.data[0].embedding

# Function to process documents and perform
#  vector search
csv_file_path = 'output_file.csv'
def process_documents(use_eng=False):
    # Determine the fields and index based on the '-eng' flag
    ctxval_field = "ctxval_eng" if use_eng else "ctxval"
    ctxemb_field = "ctxemb_eng" if use_eng else "ctxemb"
    index_name = "isbank_eng" if use_eng else "isbank"

    print(ctxval_field)
    print(ctxemb_field)
    print(index_name)

    # Initialize the Vector Store
    vs = CouchbaseVectorStore(
        cluster,
        "isbank",
        "data",
        "contexts",
        OpenAIEmbeddings(openai_api_key=openai_api_key),
        index_name,
        text_key=ctxval_field,
        embedding_key=ctxemb_field
    )

    # N1QL query to retrieve all documents from the 'prompts' collection
    query = f'SELECT META().id AS doc_id, TO_NUMBER(ctxno) AS ctxno, {ctxval_field}, {ctxemb_field} FROM `isbank`.`data`.`prompts` ORDER BY ctxno'
    print(query)
    rows = cluster.query(query)
    with open(csv_file_path, mode='w', newline='') as file:
        csv_writer = csv.writer(file)
        fieldnames = ['prompt_no', 'ctx1', 'ctx2', 'ctx3']
        writer = csv.DictWriter(file, fieldnames=fieldnames)
        writer.writeheader()
        # Iterate over the query results
       
        for row in rows:
            doc_id = row["doc_id"]
            ctxno = row["ctxno"]
            ctxval = row.get(ctxval_field)
            ctxemb = row.get(ctxemb_field)

            # If there's no 'ctxemb', generate a vector from 'ctxval'
            if not ctxemb and ctxval:
                ctxemb = generate_embedding(ctxval)
            # Perform vector search using 'ctxemb'
            if ctxemb:
                # Ensure ctxemb is a list of floats before using it for the search
                if isinstance(ctxemb, list):
                    # Adjusted to pass the vector directly for similarity search
                    results = vs.similarity_search_by_vector(ctxemb, k=3)
                    # Print the 'ctxno', score, and first 50 characters of each result
                    print(f"Results for Prompt doc key {doc_id}, ctxno: {ctxno}:")
                    i=0
                    contexts = [None] * 3
                    for result in results:
                        result_ctxno = result.metadata.get("ctxno")
                        # score = result.metadata.get("score", 0)  # Adjust based on how 'score' is provided
                        snippet = result.page_content[:60]  # Adjust based on actual data structure
                        snippet = snippet.replace('\n', '\\n') # don't print newlines
                        print(f"\tContext doc key c_{result_ctxno}, ctxno: {result_ctxno}, snippet: {snippet}")
                        print(i)
                        contexts[i]= result_ctxno
                        i = i+1
                    data = [{'prompt_no': doc_id, 'ctx1': contexts[0] , 'ctx2': contexts[1], 'ctx3': contexts[2]}]
                    
                    writer.writerows(data)
                else:
                    print(f"Invalid vector format for document {doc_id}. Expected a list of floats.")
            else:
                print(f"Document {doc_id} has no '{ctxval_field}' or vector.")

    print("Processing complete.")
def print_embeddings_contexts():

    query = f'SELECT META().id AS doc_id, TO_NUMBER(ctxno) AS ctxno,ctxval,ctxemb FROM `isbank`.`data`.`contexts` ORDER BY ctxno'
    print(query)
    rows = cluster.query(query)
    with open('context_embeddings.csv', mode='w', newline='') as file:
            csv_writer = csv.writer(file)
            fieldnames = ['context_no', 'embedding']
            csv_writer = csv.DictWriter(file, fieldnames=fieldnames)
            csv_writer.writeheader()
            for row in rows:
                doc_id = row["doc_id"]
                ctxno = row["ctxno"]
                ctxval = row['ctxval']
                ctxemb = row['ctxemb']
                data = [{'context_no': doc_id, 'embedding': ctxemb}]   
                csv_writer.writerows(data)
def print_embeddings_prompts():
    query = f'SELECT META().id AS doc_id, TO_NUMBER(ctxno) AS ctxno,ctxval,ctxemb FROM `isbank`.`data`.`prompts` ORDER BY ctxno'
    print(query)
    rows = cluster.query(query)
    with open('prompt_embeddings.csv', mode='w', newline='') as file:
            csv_writer = csv.writer(file)
            fieldnames = ['prompt_no', 'embedding']
            csv_writer = csv.DictWriter(file, fieldnames=fieldnames)
            csv_writer.writeheader()
            for row in rows:
                doc_id = row["doc_id"]
                ctxno = row["ctxno"]
                ctxval = row['ctxval']
                ctxemb = row['ctxemb']
                data = [{'prompt_no': doc_id, 'embedding': ctxemb}]   
                csv_writer.writerows(data)

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Process documents and perform vector search.')
    parser.add_argument('-eng', action='store_true', help='Use English fields and index (ctxval_eng, ctxemb_eng, isbank_eng).')

    args = parser.parse_args()
    process_documents(use_eng=args.eng)
    print_embeddings_contexts()
    print_embeddings_prompts() 